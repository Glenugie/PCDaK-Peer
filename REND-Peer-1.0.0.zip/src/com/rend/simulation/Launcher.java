package com.rend.simulation;

public class Launcher {
    public static void main(String[] args) {
        new PeerSimulation();
    }
}

